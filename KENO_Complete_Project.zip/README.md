# KENO 0.2 — Android source project

Ovo je proširena rekonstrukcija projekta KENO: Android aplikacija, MediaProjection hvatanje frejmova, osnovna analiza stola/kugli/aim linije, spin reader, simulacija sudara i overlay prikaz.

## Touch-through
Fullscreen crtački prozor koristi `FLAG_NOT_TOUCHABLE`, tako da ne prima dodire i oni prolaze do igre. K dugme je zaseban mali prozor koji prima dodir.

## Sadržaj
- Core geometrija, HSV obrada, detekcija stola i kandidata kugli
- Detekcija bijele aim linije
- Spin reader (zahtijeva poznat okvir spin widgeta; automatsko lociranje nije uključeno)
- Fizika trenja, sudara kugli i odbijanja od mantinela; približni model
- Shot predictor
- MediaProjection frame pipeline i crtanje detektovanih elemenata
- GitHub Actions build workflow, JVM 17

## Ograničenja
Ovo je funkcionalna osnova, ne potvrđena precizna alatka za takmičarsku igru. Detekcija slike je heuristička i može griješiti zbog grafike, sjena, animacija i različitih tema/rezolucija. Spin widget se još ne locira automatski niti se rezultat spina pouzdano kalibriše. Putanje su aproksimacija, nisu validirane protiv stvarne fizike igre. Overlay se ne koristi za zaobilaženje zaštita igre.

## Build
Uploaduj sadržaj ZIP-a u root GitHub repozitorija. Actions → Build KENO APK → preuzmi artifact `KENO-debug-apk`.
