package com.keno.billiards.core

import kotlin.math.*

data class Vec2(val x: Double, val y: Double) {
    operator fun plus(o: Vec2) = Vec2(x + o.x, y + o.y)
    operator fun minus(o: Vec2) = Vec2(x - o.x, y - o.y)
    operator fun times(k: Double) = Vec2(x * k, y * k)
    operator fun div(k: Double) = Vec2(x / k, y / k)
    fun dot(o: Vec2) = x * o.x + y * o.y
    fun length() = hypot(x, y)
    fun normalized(): Vec2 = if (length() < 1e-9) Vec2(0.0, 0.0) else this / length()
    fun distance(o: Vec2) = (this - o).length()
    fun perpendicular() = Vec2(-y, x)
}
data class RectD(val left: Double, val top: Double, val right: Double, val bottom: Double) {
    val width get() = right-left
    val height get() = bottom-top
    fun contains(p: Vec2) = p.x in left..right && p.y in top..bottom
    fun clamp(p: Vec2) = Vec2(p.x.coerceIn(left,right), p.y.coerceIn(top,bottom))
    fun inset(v: Double) = RectD(left+v, top+v, right-v, bottom-v)
}
data class Rgb(val r:Int,val g:Int,val b:Int)
data class Frame(val width:Int,val height:Int,val pixels:IntArray) {
    fun rgb(x:Int,y:Int): Rgb {
        val c=pixels[y.coerceIn(0,height-1)*width+x.coerceIn(0,width-1)]
        return Rgb((c shr 16) and 255,(c shr 8) and 255,c and 255)
    }
}
data class Ball(val center:Vec2,val radius:Double,val color:Int=0xFFFFFF,val isCue:Boolean=false)
data class Table(val bounds:RectD,val pockets:List<Vec2>,val ballRadius:Double)
