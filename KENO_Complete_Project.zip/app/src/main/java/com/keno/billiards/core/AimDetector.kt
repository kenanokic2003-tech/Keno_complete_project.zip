package com.keno.billiards.core

import kotlin.math.*

data class AimLine(val origin:Vec2,val direction:Vec2,val length:Double)
object AimDetector {
    fun detect(frame:Frame,table:Table,cue:Ball?):AimLine? {
        if(cue==null) return null
        var best: AimLine?=null; var bestScore=0
        for(deg in 0 until 360 step 2) {
            val a=Math.toRadians(deg.toDouble()); val d=Vec2(cos(a),sin(a))
            var score=0; var run=0; var maxRun=0
            for(t in 0..(min(table.bounds.width,table.bounds.height)*.48).toInt() step 3) {
                val p=cue.center+d*t.toDouble()
                if(!table.bounds.contains(p)) break
                val c=frame.rgb(p.x.toInt(),p.y.toInt()); val h=ImageMath.hsv(c)
                if(h.v>.72 && h.s<.30) { score++; run++ } else run=0
                maxRun=max(maxRun,run)
            }
            score+=maxRun*2
            if(score>bestScore && maxRun>=3) { bestScore=score; best=AimLine(cue.center,d,score*2.5) }
        }
        return best
    }
}
