package com.keno.billiards

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.media.projection.MediaProjectionManager
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import com.keno.billiards.overlay.KenoOverlayService

class MainActivity : Activity() {
    companion object { private const val REQUEST_CAPTURE = 4102 }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val l = LinearLayout(this).apply { orientation = 1; setPadding(28, 40, 28, 28) }
        l.addView(TextView(this).apply {
            text = "KENO 0.2\\n\\nAsistent za 8 Ball Pool. Uključi dozvolu za prikaz preko drugih aplikacija, pa pokreni KENO."
            textSize = 18f
        })
        l.addView(Button(this).apply {
            text = "1. Dozvoli prikaz preko aplikacija"
            setOnClickListener { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) }
        })
        l.addView(Button(this).apply {
            text = "2. Pokreni KENO"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    Toast.makeText(this@MainActivity, "Prvo uključi overlay dozvolu", Toast.LENGTH_LONG).show()
                } else {
                    val m = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                    startActivityForResult(m.createScreenCaptureIntent(), REQUEST_CAPTURE)
                }
            }
        })
        l.addView(Button(this).apply {
            text = "Zaustavi KENO"
            setOnClickListener { stopService(Intent(this@MainActivity, KenoOverlayService::class.java)) }
        })
        setContentView(l)
    }
    @Deprecated("Deprecated by Android; retained for device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_CAPTURE && resultCode == RESULT_OK && data != null) {
            startForegroundService(Intent(this, KenoOverlayService::class.java).apply {
                action = KenoOverlayService.START
                putExtra(KenoOverlayService.CODE, resultCode)
                putExtra(KenoOverlayService.DATA, data)
            })
        }
    }
}
