package com.keno.billiards.overlay

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.provider.Settings
import android.view.*
import android.widget.Button
import android.widget.Toast
import android.graphics.drawable.GradientDrawable
import com.keno.billiards.core.*

class KenoOverlayService : Service() {
    companion object { const val START="keno.start"; const val CODE="result.code"; const val DATA="result.data"; private const val CHANNEL="keno_capture" }
    private lateinit var wm:WindowManager
    private var full:PredictionView?=null
    private var floating:View?=null
    private var projection:MediaProjection?=null
    private var reader:ImageReader?=null
    private var display:VirtualDisplay?=null
    private var thread:HandlerThread?=null
    private var handler:Handler?=null
    private var lastAnalysis=0L

    override fun onBind(intent:Intent?):IBinder?=null
    override fun onStartCommand(intent:Intent?,flags:Int,id:Int):Int {
        if(intent?.action==START) {
            if(!Settings.canDrawOverlays(this)){stopSelf();return START_NOT_STICKY}
            makeChannel()
            val nb=if(Build.VERSION.SDK_INT>=26) Notification.Builder(this,CHANNEL) else Notification.Builder(this)
            startForeground(91,nb.setContentTitle("KENO je aktivan").setContentText("Analiza ekrana je uključena").setSmallIcon(android.R.drawable.ic_menu_view).build())
            wm=getSystemService(WINDOW_SERVICE) as WindowManager
            addWindows(); beginCapture(intent)
        }
        return START_NOT_STICKY
    }
    private fun addWindows() {
        full=PredictionView(this)
        val flags=WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
        wm.addView(full,WindowManager.LayoutParams(-1,-1,type(),flags,PixelFormat.TRANSLUCENT))
        floating=Button(this).apply {
            text="K"; textSize=17f; setTextColor(Color.WHITE)
            background=GradientDrawable().apply{shape=GradientDrawable.OVAL;setColor(Color.rgb(10,105,175))}
            setOnClickListener{full?.toggle()}
        }
        val p=WindowManager.LayoutParams(54.dp(),54.dp(),type(),WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,PixelFormat.TRANSLUCENT)
        p.gravity=Gravity.TOP or Gravity.END;p.x=12.dp();p.y=140.dp();wm.addView(floating,p)
    }
    private fun beginCapture(i:Intent) {
        val code=i.getIntExtra(CODE,0)
        @Suppress("DEPRECATION")
        val data=if(Build.VERSION.SDK_INT>=33)i.getParcelableExtra(DATA,Intent::class.java) else i.getParcelableExtra(DATA)
        if(data==null)return
        val mgr=getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection=mgr.getMediaProjection(code,data)
        thread=HandlerThread("KENO-frame-worker").also{it.start()};handler=Handler(thread!!.looper)
        val dm=resources.displayMetrics
        reader=ImageReader.newInstance(dm.widthPixels,dm.heightPixels,PixelFormat.RGBA_8888,2)
        reader?.setOnImageAvailableListener({r->
            val now=System.currentTimeMillis()
            if(now-lastAnalysis<100)return@setOnImageAvailableListener
            lastAnalysis=now
            var image:Image?=null
            try {
                image=r.acquireLatestImage() ?: return@setOnImageAvailableListener
                val plane=image.planes[0];val buffer=plane.buffer
                val w=image.width;val h=image.height;val pixelStride=plane.pixelStride;val rowStride=plane.rowStride
                val rowPadding=rowStride-pixelStride*w
                val bmp=Bitmap.createBitmap(w+rowPadding/pixelStride,h,Bitmap.Config.ARGB_8888)
                bmp.copyPixelsFromBuffer(buffer)
                val cropped=Bitmap.createBitmap(bmp,0,0,w,h);bmp.recycle()
                val scaledW=900.coerceAtMost(w);val scaledH=(h.toDouble()*scaledW/w).toInt().coerceAtLeast(1)
                val scaled=Bitmap.createScaledBitmap(cropped,scaledW,scaledH,true);cropped.recycle()
                val pixels=IntArray(scaledW*scaledH);scaled.getPixels(pixels,0,scaledW,0,0,scaledW,scaledH);scaled.recycle()
                val result=KenoAnalyzer.analyze(Frame(scaledW,scaledH,pixels))
                full?.post { full?.update(result,w.toFloat()/scaledW,h.toFloat()/scaledH) }
            } catch(_:Throwable) { } finally { image?.close() }
        },handler)
        display=projection?.createVirtualDisplay("KENO-screen",dm.widthPixels,dm.heightPixels,dm.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader?.surface,null,handler)
    }
    private fun type()=if(Build.VERSION.SDK_INT>=26)WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
    private fun Int.dp()=(this*resources.displayMetrics.density).toInt()
    private fun makeChannel(){if(Build.VERSION.SDK_INT>=26)(getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(NotificationChannel(CHANNEL,"KENO capture",NotificationManager.IMPORTANCE_LOW))}
    override fun onDestroy(){
        try{display?.release()}catch(_:Exception){};try{reader?.close()}catch(_:Exception){};try{projection?.stop()}catch(_:Exception){}
        try{thread?.quitSafely()}catch(_:Exception){};try{floating?.let{wm.removeView(it)}}catch(_:Exception){};try{full?.let{wm.removeView(it)}}catch(_:Exception){}
        super.onDestroy()
    }

    inner class PredictionView(ctx:Context):View(ctx) {
        private val p=Paint(Paint.ANTI_ALIAS_FLAG)
        private var result:AnalysisResult?=null
        private var sx=1f;private var sy=1f;private var visible=true
        fun toggle(){visible=!visible;invalidate()}
        fun update(r:AnalysisResult,x:Float,y:Float){result=r;sx=x;sy=y;invalidate()}
        override fun onDraw(c:Canvas){
            super.onDraw(c);if(!visible)return
            val r=result?:return
            c.save();c.scale(sx,sy)
            r.table?.let{t->
                p.color=Color.argb(160,0,255,180);p.style=Paint.Style.STROKE;p.strokeWidth=2f
                c.drawRect(t.bounds.left.toFloat(),t.bounds.top.toFloat(),t.bounds.right.toFloat(),t.bounds.bottom.toFloat(),p)
                t.pockets.forEach{c.drawCircle(it.x.toFloat(),it.y.toFloat(),t.ballRadius.toFloat()*1.6f,p)}
            }
            r.balls.forEach{b->
                p.color=if(b.isCue)Color.WHITE else Color.YELLOW;p.style=Paint.Style.STROKE;p.strokeWidth=3f
                c.drawCircle(b.center.x.toFloat(),b.center.y.toFloat(),b.radius.toFloat(),p)
            }
            r.aim?.let{a->
                p.color=Color.CYAN;p.strokeWidth=3f
                c.drawLine(a.origin.x.toFloat(),a.origin.y.toFloat(),(a.origin.x+a.direction.x*a.length).toFloat(),(a.origin.y+a.direction.y*a.length).toFloat(),p)
            }
            c.restore()
        }
    }
}
