package com.keno.billiards.core

import kotlin.math.*

object ImageMath {
    data class Hsv(val h:Double,val s:Double,val v:Double)
    fun hsv(c:Rgb):Hsv {
        val r=c.r/255.0; val g=c.g/255.0; val b=c.b/255.0
        val mx=max(r,max(g,b)); val mn=min(r,min(g,b)); val d=mx-mn
        var h=when {
            d==0.0 -> 0.0
            mx==r -> 60.0*(((g-b)/d)%6.0)
            mx==g -> 60.0*((b-r)/d+2.0)
            else -> 60.0*((r-g)/d+4.0)
        }
        if(h<0) h+=360.0
        return Hsv(h,if(mx==0.0) 0.0 else d/mx,mx)
    }
    fun median(values:List<Double>):Double = if(values.isEmpty()) 0.0 else values.sorted()[values.size/2]
    fun colorDistance(a:Rgb,b:Rgb)=sqrt(((a.r-b.r)*(a.r-b.r)+(a.g-b.g)*(a.g-b.g)+(a.b-b.b)*(a.b-b.b)).toDouble())
}
