package com.keno.billiards.core

import kotlin.math.*

data class PhysicsParams(
    val friction:Double=.22, val restitution:Double=.92, val cushionRestitution:Double=.82,
    val spinStrength:Double=.35, val maxTime:Double=8.0, val dt:Double=.012
)
data class SimBall(var p:Vec2,var v:Vec2,val radius:Double,val cue:Boolean=false,var spinX:Double=0.0,var spinY:Double=0.0)
data class SimResult(val paths:List<List<Vec2>>,val finalBalls:List<SimBall>)
object Physics {
    fun simulate(input:List<SimBall>,bounds:RectD,params:PhysicsParams=PhysicsParams()):SimResult {
        val balls=input.map{it.copy()}
        val paths=balls.map{mutableListOf(it.p)}
        var time=0.0
        while(time<params.maxTime && balls.any{it.v.length()>.025}) {
            for((i,b) in balls.withIndex()) {
                if(b.v.length()>.002) {
                    val speed=b.v.length()
                    val drag=params.friction*params.dt
                    val newSpeed=max(0.0,speed-drag)
                    b.v=b.v.normalized()*newSpeed
                    // Side spin introduces a small lateral curve; top/back spin changes speed decay.
                    val curve=b.spinX*params.spinStrength*params.dt*speed*.35
                    b.v=b.v + b.v.normalized().perpendicular()*curve
                    b.p=b.p+b.v*params.dt
                }
                val r=b.radius
                if(b.p.x<bounds.left+r) { b.p=Vec2(bounds.left+r,b.p.y); b.v=Vec2(abs(b.v.x)*params.cushionRestitution,b.v.y); b.spinX *= .72 }
                if(b.p.x>bounds.right-r) { b.p=Vec2(bounds.right-r,b.p.y); b.v=Vec2(-abs(b.v.x)*params.cushionRestitution,b.v.y); b.spinX *= .72 }
                if(b.p.y<bounds.top+r) { b.p=Vec2(b.p.x,bounds.top+r); b.v=Vec2(b.v.x,abs(b.v.y)*params.cushionRestitution) }
                if(b.p.y>bounds.bottom-r) { b.p=Vec2(b.p.x,bounds.bottom-r); b.v=Vec2(b.v.x,-abs(b.v.y)*params.cushionRestitution) }
                paths[i].add(b.p)
            }
            for(i in balls.indices) for(j in i+1 until balls.size) {
                val a=balls[i]; val b=balls[j]; val delta=b.p-a.p; val dist=delta.length(); val minD=a.radius+b.radius
                if(dist>1e-6 && dist<minD) {
                    val n=delta/dist; val rel=(a.v-b.v).dot(n)
                    if(rel>0) {
                        val impulse=(1+params.restitution)*rel/2.0
                        a.v=a.v-n*impulse; b.v=b.v+n*impulse
                    }
                    val overlap=(minD-dist)/2.0
                    a.p=a.p-n*overlap; b.p=b.p+n*overlap
                }
            }
            time+=params.dt
        }
        return SimResult(paths,balls)
    }
    fun strike(cue:Ball,angle:Double,power:Double,spinX:Double,spinY:Double,balls:List<Ball>,table:Table):SimResult {
        val speed=1.2+power.coerceIn(0.0,1.0)*4.5
        val all=balls.map { b ->
            val v=if(b.isCue) Vec2(cos(angle)*speed,sin(angle)*speed) else Vec2(0.0,0.0)
            SimBall(b.center,v,b.radius,b.isCue,spinX,spinY)
        }
        return simulate(all,table.bounds.inset(cue.radius),PhysicsParams(spinStrength=.42+abs(spinY)*.2))
    }
}
