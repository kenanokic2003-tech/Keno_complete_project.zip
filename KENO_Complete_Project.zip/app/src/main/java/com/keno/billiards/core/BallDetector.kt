package com.keno.billiards.core

import kotlin.math.*

object BallDetector {
    private data class Candidate(val x:Int,val y:Int,val color:Int)
    fun detect(frame:Frame,table:Table):List<Ball> {
        val step=max(1,(table.ballRadius/3.0).roundToInt())
        val candidates=ArrayList<Candidate>()
        val x0=table.bounds.left.toInt(); val x1=table.bounds.right.toInt()
        val y0=table.bounds.top.toInt(); val y1=table.bounds.bottom.toInt()
        for(y in y0..y1 step step) for(x in x0..x1 step step) {
            val c=frame.rgb(x,y); val hsv=ImageMath.hsv(c)
            val brightWhite=hsv.v>.72 && hsv.s<.28
            val saturated=hsv.s>.42 && hsv.v>.24
            if(brightWhite || saturated) candidates.add(Candidate(x,y,(c.r shl 16) or (c.g shl 8) or c.b))
        }
        val minDist=table.ballRadius*1.2
        val clusters=ArrayList<MutableList<Candidate>>()
        for(p in candidates) {
            val group=clusters.firstOrNull { g ->
                val cx=g.map{it.x}.average(); val cy=g.map{it.y}.average()
                hypot(cx-p.x,cy-p.y)<minDist
            }
            if(group!=null) group.add(p) else clusters.add(mutableListOf(p))
        }
        val result=ArrayList<Ball>()
        for(g in clusters) {
            if(g.size<3) continue
            val cx=g.map{it.x.toDouble()}.average(); val cy=g.map{it.y.toDouble()}.average()
            val spread=g.maxOf { hypot(it.x-cx,it.y-cy) }
            if(spread !in table.ballRadius*.35..table.ballRadius*1.8) continue
            val center=Vec2(cx,cy)
            if(result.any{it.center.distance(center)<table.ballRadius*1.3}) continue
            val samples=g.map{frame.rgb(it.x,it.y)}
            val avg=Rgb(samples.map{it.r}.average().roundToInt(),samples.map{it.g}.average().roundToInt(),samples.map{it.b}.average().roundToInt())
            val cue=ImageMath.hsv(avg).s<.25 && ImageMath.hsv(avg).v>.65
            result.add(Ball(center,table.ballRadius,(avg.r shl 16) or (avg.g shl 8) or avg.b,cue))
        }
        return result.take(16)
    }
}
