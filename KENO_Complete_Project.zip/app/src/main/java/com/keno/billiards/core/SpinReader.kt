package com.keno.billiards.core

import kotlin.math.*

data class SpinReading(val x:Double,val y:Double,val found:Boolean)
object SpinReader {
    fun read(frame:Frame,widget:RectD?):SpinReading {
        if(widget==null) return SpinReading(0.0,0.0,false)
        var sx=0.0; var sy=0.0; var n=0
        for(y in widget.top.toInt()..widget.bottom.toInt()) for(x in widget.left.toInt()..widget.right.toInt()) {
            val c=frame.rgb(x,y)
            if(c.r>145 && c.r>c.g*1.35 && c.r>c.b*1.25) { sx+=x; sy+=y; n++ }
        }
        if(n<2) return SpinReading(0.0,0.0,false)
        val cx=sx/n; val cy=sy/n
        val rx=max(1.0,widget.width/2); val ry=max(1.0,widget.height/2)
        return SpinReading(((cx-(widget.left+rx))/rx).coerceIn(-1.0,1.0),
            ((cy-(widget.top+ry))/ry).coerceIn(-1.0,1.0),true)
    }
}
