package com.keno.billiards.core

data class AnalysisResult(val table:Table?,val balls:List<Ball>,val cue:Ball?,val aim:AimLine?,val spin:SpinReading)
object KenoAnalyzer {
    fun analyze(frame:Frame,spinWidget:RectD?=null):AnalysisResult {
        val table=TableDetector.detect(frame) ?: return AnalysisResult(null, emptyList(),null,null,SpinReading(0.0,0.0,false))
        val balls=BallDetector.detect(frame,table)
        val cue=balls.firstOrNull{it.isCue}
        val aim=AimDetector.detect(frame,table,cue)
        val spin=SpinReader.read(frame,spinWidget)
        return AnalysisResult(table,balls,cue,aim,spin)
    }
}
