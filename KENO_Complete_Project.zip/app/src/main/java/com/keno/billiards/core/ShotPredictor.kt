package com.keno.billiards.core

import kotlin.math.*

data class ShotPrediction(val cuePath:List<Vec2>,val objectPaths:List<List<Vec2>>,val contact:Vec2?)
object ShotPredictor {
    fun predict(balls:List<Ball>,table:Table,aim:AimLine,spinX:Double=0.0,spinY:Double=0.0,power:Double=.65):ShotPrediction? {
        val cue=balls.firstOrNull{it.isCue} ?: return null
        val result=Physics.strike(cue,atan2(aim.direction.y,aim.direction.x),power,spinX,spinY,balls,table)
        val cueIndex=balls.indexOf(cue)
        val cuePath=result.paths.getOrNull(cueIndex) ?: emptyList()
        var contact:Vec2?=null
        val firstObject=balls.filter{!it.isCue}.minByOrNull { b ->
            val d=aim.direction.normalized()
            val along=(b.center-cue.center).dot(d)
            val perp=abs((b.center-cue.center).dot(d.perpendicular()))
            if(along>0 && perp<cue.radius*2.3) along else Double.MAX_VALUE
        }
        if(firstObject!=null) {
            val d=aim.direction.normalized()
            val along=(firstObject.center-cue.center).dot(d)
            contact=cue.center+d*(along-cue.radius*2)
        }
        return ShotPrediction(cuePath,result.paths.filterIndexed{i,_->i!=cueIndex},contact)
    }
}
