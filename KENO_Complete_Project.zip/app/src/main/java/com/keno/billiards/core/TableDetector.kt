package com.keno.billiards.core

import kotlin.math.*

object TableDetector {
    fun detect(frame:Frame):Table? {
        val step=max(2,min(frame.width,frame.height)/240)
        var minX=frame.width; var minY=frame.height; var maxX=0; var maxY=0; var count=0
        for(y in step until frame.height-step step step) for(x in step until frame.width-step step) {
            val h=ImageMath.hsv(frame.rgb(x,y))
            // Pool felt: green/blue-green hue, moderate saturation and brightness.
            if(h.h in 75.0..190.0 && h.s>.22 && h.v in .12.. .88) {
                count++; minX=min(minX,x); minY=min(minY,y); maxX=max(maxX,x); maxY=max(maxY,y)
            }
        }
        if(count < frame.width*frame.height/(step*step)*.035) return null
        val bounds=RectD(minX.toDouble(),minY.toDouble(),maxX.toDouble(),maxY.toDouble())
        if(bounds.width < frame.width*.35 || bounds.height < frame.height*.22) return null
        val r=min(bounds.width,bounds.height)*.018
        val inset=r*1.3
        val b=bounds.inset(inset)
        val pockets=listOf(Vec2(b.left,b.top),Vec2((b.left+b.right)/2,b.top),Vec2(b.right,b.top),
            Vec2(b.left,b.bottom),Vec2((b.left+b.right)/2,b.bottom),Vec2(b.right,b.bottom))
        return Table(b,pockets,r)
    }
}
